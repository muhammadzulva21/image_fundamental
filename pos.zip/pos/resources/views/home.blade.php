<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Submission</title>
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">
</head>
<body>

<div class="hidden-text" id="status-text"></div>

<form id="myForm">
    <div>
        <label for="id_pelanggan">Nama Pelanggan :</label>
        <select id="id_pelanggan" name="id_pelanggan" required>
            <option value="">Pilih Nama Anda</option>
            @foreach($pelanggans as $pelanggan)
                <option value="{{ $pelanggan->id_pelanggan }}">{{ $pelanggan->nama_pelanggan }}</option>
            @endforeach
        </select>
    </div>

    <div>
        <label for="jumlah">Jumlah Barang :</label>
        <input type="number" id="jumlah" name="jumlah" required>
    </div>

    <div>
        <label for="id_barang">Barang :</label>
        <select id="id_barang" name="id_barang" required>
            <option value="">Pilih Barang</option>
            @foreach($barangs as $barang)
                <option value="{{ $barang->id_barang }}">{{ $barang->nama_barang }}</option>
            @endforeach
        </select>
    </div>

    <div>
        <input type="button" value="Submit" onclick="submitForm()" id="button">
    </div>
</form>

<script>
   
</script>
</body>
</html>
