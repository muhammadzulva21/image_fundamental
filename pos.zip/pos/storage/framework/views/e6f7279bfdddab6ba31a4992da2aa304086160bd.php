<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Submission</title>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>
<body>

<div class="hidden-text" id="status-text"></div>

<form id="myForm">
    <div>
        <label for="id_pelanggan">Nama Pelanggan :</label>
        <select id="id_pelanggan" name="id_pelanggan" required>
            <option value="">Pilih Nama Anda</option>
            <?php $__currentLoopData = $pelanggans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pelanggan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pelanggan->id_pelanggan); ?>"><?php echo e($pelanggan->nama_pelanggan); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div>
        <label for="jumlah">Jumlah Barang :</label>
        <input type="number" id="jumlah" name="jumlah" required>
    </div>

    <div>
        <label for="id_barang">Barang :</label>
        <select id="id_barang" name="id_barang" required>
            <option value="">Pilih Barang</option>
            <?php $__currentLoopData = $barangs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($barang->id_barang); ?>"><?php echo e($barang->nama_barang); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div>
        <input type="button" value="Submit" onclick="submitForm()" id="button">
    </div>
</form>

<script>
   
</script>
</body>
</html>
<?php /**PATH E:\Xampp\htdocs\pos\resources\views/home.blade.php ENDPATH**/ ?>