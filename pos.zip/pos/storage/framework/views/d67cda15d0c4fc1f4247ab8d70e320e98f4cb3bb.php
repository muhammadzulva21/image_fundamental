<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Form Submission</title>
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
</head>
<body>

<div class="hidden-text" id="status-text">
   
</div>

<form id="myForm">
    <div>
        <label for="nama">Nama :</label>
        <input type="text" id="nama" name="nama" required>
    </div>

    <div>
        <label for="alamat">Alamat :</label>
        <input type="text" id="alamat" name="alamat" required>
    </div>

    <div>
        <label for="telepon">Nomor Telepon :</label>
        <input type="text" id="telepon" name="telepon" required>
    </div>

    <div>
        <label for="jenisKelamin">Jenis Kelamin :</label>
        <select id="jenisKelamin" name="jenisKelamin" required>
            <option value="laki-laki">Laki-laki</option>
            <option value="perempuan">Perempuan</option>
        </select>
    </div>

    <div>
        <input type="button" value="Submit" onclick="submitForm()" id="button">
    </div>
</form>

<script>
    function submitForm() {
        var xhr = new XMLHttpRequest();
        var formData = new FormData(document.getElementById("myForm"));

        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4 && xhr.status == 200) {
                var response = JSON.parse(xhr.responseText);
                displayMessage(response.message);
            }
        };

        xhr.open("POST", "submit_form.php", true);
        xhr.send(formData);
    }

    function displayMessage(message) {
        console.log(message)
        var statusText = document.getElementById("status-text");
        statusText.innerHTML = message;
        statusText.style.display = "block";
        setTimeout(function () {
            statusText.style.display = "none";
        }, 60000);
    }
</script>
</body>
</html>
<?php /**PATH E:\Xampp\htdocs\pos\resources\views/welcome.blade.php ENDPATH**/ ?>